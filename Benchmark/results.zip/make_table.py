import os
import sys
import zlib
from math import sqrt

#---------------------------------------------------------------
def read_data(file_name):
    sum = 0.0
    sum2 = 0.0
    n = 0
    with open(file_name) as f:
        lines = f.readlines()
        for s in lines:
            try:
                v = float(s)
                if v > 0:
                    sum += v
                    sum2 += v*v
                    n += 1
            except:
                print("    empty string or bad number")
    
    mean = 0
    std = 0
    if n > 0:
        mean = sum/n
        std = sqrt(sum2/n - mean*mean)
    return (mean,std)


def process_folder(dir, table):   
    accmean, accstd = read_data(dir+"\\acc.txt")
    maxmean, maxstd = read_data(dir+"\\max.txt")
            
    line = '\t\t%s ±%s\t%s ±%s' % (int(accmean), int(accstd), int(maxmean), int(maxstd))
            
    table.write(line.encode('utf-8'))
    
    
#---------------------------------------------------------------
walk_dir = "." #sys.argv[1]

print("---- Make results table ----")

out_file = "table.txt"  #os.path.join(root, 'my-directory-list.txt')
with open(out_file, 'wb') as table:
    table.write(("Name                      \t\tSmall\t(max)\t\tMedium\t(max)\t\tHeavy\t(max)\t\tFull\t(max)\t\tHuge\t(max)\n").encode('utf-8'))
                  
    table.write(b'\n')

    for root, subdirs, files in os.walk(walk_dir):
        #print("   ", root)
        #.\cpp_alexey_antropov
        #.\cpp_alexey_antropov\01
        #.\cpp_alexey_antropov\02
        x = root.split("\\")
        #print(x)
        if len(x)==2:
            print(x[1],":")
            table.write(b'\n')
            table.write(x[1].encode('utf-8'))
            line = x[1]
            
            process_folder(root+"\\01", table)
            process_folder(root+"\\02", table)
            process_folder(root+"\\03", table)
            process_folder(root+"\\04", table)
            process_folder(root+"\\05", table)
            
        #if len(x)==3:
        #    print("  ",x[2])
            
            
print()            
print("Done, result is saved to '" + out_file + "'")

# input("Press Enter to continue...")
